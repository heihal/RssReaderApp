package fi.halmetoja.rssreader

import android.os.Build

import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
class HTTPDataHandler {

    fun getHandleri(urli:String) {
        try
        {
            val url = URL(urli)
            val urlC = url.openConnection() as HttpURLConnection
            if (urlC.getResponseCode() == HttpURLConnection.HTTP_OK)
            {
                val ips = BufferedInputStream(urlC.getInputStream())
                val reader = BufferedReader(InputStreamReader(ips))
                val sb = StringBuilder()
                var line: String? = null;
                while ({ line = reader.readLine(); line }() != null) {
                    sb.append(line)
                    virta = sb.toString()
                    urlC.disconnect()
                }
            }
        }
        catch (e:Exception) {
            println(e)
        }
    }
    companion object {
        internal var virta = ""
    }
}