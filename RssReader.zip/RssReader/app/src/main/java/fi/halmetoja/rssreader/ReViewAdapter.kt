package fi.halmetoja.rssreader

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.rivi.view.*
import java.lang.reflect.AccessibleObject

class FeediHolder(itemView: View): RecyclerView.ViewHolder(itemView), View.OnClickListener,View.OnLongClickListener
{

    var title : TextView
    var  pvm : TextView
    var sisalto : TextView

    var klikkiKuuntelija : KlikkiKuuntelija?=null

    init {
        title= itemView.findViewById((R.id.otsake)) as TextView
        pvm= itemView.findViewById((R.id.pvm)) as TextView
        sisalto= itemView.findViewById((R.id.sisalto)) as TextView

        itemView.setOnClickListener(this)
        itemView.setOnLongClickListener(this)
    }
    fun setItemClickListener(klikkiKuuntelija: KlikkiKuuntelija) {
        this.klikkiKuuntelija =klikkiKuuntelija
    }

    override fun onClick(v: View?) {
        if (v != null) {
            klikkiKuuntelija!!.onClick(v,adapterPosition, false)
        }
    }

    override fun onLongClick(v: View?): Boolean {
        if (v != null) {
            klikkiKuuntelija!!.onClick(v,adapterPosition, true)
        }
        return true;
    }

}

class ReViewAdapter(val rssObject: RSSObject,val konteksti:Context): RecyclerView.Adapter<FeediHolder>()
{
    private val inflater:LayoutInflater
    init {
        inflater= LayoutInflater.from(konteksti)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FeediHolder {
        return FeediHolder(inflater.inflate(R.layout.rivi,parent,false))
    }

    override fun getItemCount(): Int {
        return rssObject.items.size
    }

    ///lisää muitakin juttuja kuten image ja mitä näitä nyt on
    override fun onBindViewHolder(holder: FeediHolder, position: Int) {
        holder.title.text= rssObject.items[position].title
        holder.sisalto.text= rssObject.items[position].content
        holder.pvm.text= rssObject.items[position].pubDate


        holder.setItemClickListener(object:KlikkiKuuntelija{
             fun onItemClicked(isLongClick: Boolean, position: Int, v: View ){
                //Jos tyyppi klikkaa viewta niin avaa postin uuteen ikkunaan
                 if (!isLongClick){
                     val bi=Intent(Intent.ACTION_VIEW,Uri.parse(rssObject.items[position].link))
                     konteksti.startActivity(bi)
                 }
             }


    })
    }


}