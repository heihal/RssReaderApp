package fi.halmetoja.rssreader

import android.view.View

public interface KlikkiKuuntelija {
    fun onClick(v: View, pos : Int,klikattu: Boolean) {

    }

}