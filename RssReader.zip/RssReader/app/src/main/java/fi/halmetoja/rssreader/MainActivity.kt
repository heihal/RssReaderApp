package fi.halmetoja.rssreader

import android.annotation.SuppressLint

import android.os.AsyncTask
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager

import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    var rssLinks: ArrayList<String> = ArrayList()
    private val RSSlink= "https://feeds.yle.fi/uutiset/v1/recent.rss?publisherIds=YLE_UUTISET"
    private val RSS_to_JSON_API = "https://api.rss2json.com/v1/api.json?rss_url=https%3A%2F%2Ffeeds.yle.fi%2Fuutiset%2Fv1%2Frecent.rss%3FpublisherIds%3DYLE_UUTISET"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        toolbar.title = "uutissii"
        setSupportActionBar(toolbar)

        refresh.setOnClickListener {
            loadRSS()
        }
        val manager= LinearLayoutManager(baseContext,LinearLayoutManager.VERTICAL,false)
        recycler.layoutManager = manager

        //rss-linkit
        rssLinks.add("https://feeds.yle.fi/uutiset/v1/recent.rss?publisherIds=YLE_UUTISET")
        loadRSS()
    }

   private fun loadRSS() {
        val loadi = @SuppressLint("StaticFieldLeak")
        object:AsyncTask<String,String,String>(){
            override fun onPostExecute(result: String?) {
                var rssObject:RSSObject
                rssObject= Gson().fromJson<RSSObject>(result,RSSObject::class.java!!)
                val adapter= ReViewAdapter(rssObject,baseContext)
                recycler.adapter= adapter
                adapter.notifyDataSetChanged()
            }
            override fun doInBackground(vararg params: String?): String {
                val result:String
                val http:HTTPDataHandler = HTTPDataHandler()
                result = params[0]?.let { http.getHandleri(it).toString() }.toString()
                return result

            }
        }

       val url_get_data= StringBuilder(RSS_to_JSON_API)
       url_get_data.append(RSSlink)
       loadi.execute((url_get_data.toString()))
    }




    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }
}
